from django.urls import path
from doctor_app import views
urlpatterns = [
    path("", views.inicio_vista, name="inicio_vista"),
    path("registrarDoctor/",views.registrarDoctor,name="registrarDoctor"),
    path("seleccionarDoctor/<id_doctor>",views.seleccionarDoctor,name="seleccionarDoctor"),
    path("editarDoctor/",views.editarDoctor,name="editarDoctor"),
    path("borrarDoctor/<id_doctor>",views.borrarDoctor,name="borrarDoctor")
]